
<li><a href="/" class="">Home</a>
          <?php $__currentLoopData = $cates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

          <?php if($cate->parent == 0): ?>
  

        <li><a onclick="myCategory(<?php echo e($cate->id); ?>)" aria-expanded="false" class=""><?php echo e($cate->cname); ?></a>

          <div class="uk-navbar-dropdown uk-navbar-dropdown-bottom-left" style="left: 0px; top: 80px;">

            <ul class="uk-nav uk-navbar-dropdown-nav">
              
              <?php $__currentLoopData = $cates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cate1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


              <?php if($cate1->parent == $cate->id): ?>


              <li class="uk-active"><a onclick="myCategory(<?php echo e($cate1->id); ?>)"><?php echo e($cate1->cname); ?></a></li>

   <?php endif; ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>

          </div>

        </li>

        <?php endif; ?>


         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH C:\Users\O.S.S\Desktop\New folder (7)\image-management-api\resources\views/cate/html.blade.php ENDPATH**/ ?>