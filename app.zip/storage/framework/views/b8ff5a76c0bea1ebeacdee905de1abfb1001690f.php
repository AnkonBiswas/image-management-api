<html>
	<head></head>
	<body>
<form method="post">
		<?php echo e(csrf_field()); ?>


		 <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

		<img width="30%" src="/upload/<?php echo e($image->name); ?>" alt="">
		<input type="hidden" name="image" value="<?php echo e($image->name); ?>">

		Rotate :

		 <div class="uk-margin uk-grid-small uk-child-width-auto uk-grid">
            <label><input class="uk-radio" type="radio" name="rotate" checked value="-90"> Left</label>
            <label><input class="uk-radio" type="radio" name="rotate" value="90"> Right</label>
        </div>

        <input type="submit" value="Submit">

		 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		 </form>
	</body>
</html><?php /**PATH C:\Users\O.S.S\Desktop\New folder (7)\image-management-api\resources\views/image/rotate.blade.php ENDPATH**/ ?>